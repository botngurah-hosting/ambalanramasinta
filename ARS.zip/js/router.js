function updateNavVisibility() {
  const bottomNav = document.getElementById("bottom-nav");
  if (!bottomNav) return;

  if (userRole === "user") {
    bottomNav.classList.remove("hidden");
    bottomNav.classList.add("flex");
    bottomNav.innerHTML = `
      <button onclick="navigateTo('edit')" class="flex flex-col items-center justify-center w-20 py-1 text-slate-500 hover:text-sky-600 transition-all group">
        <span class="text-xl group-hover:scale-110 transition-transform">✏️</span>
        <span class="text-[10px] font-extrabold mt-0.5 text-slate-600 group-hover:text-sky-600">Edit</span>
      </button>

      <button onclick="navigateTo('user')" class="flex flex-col items-center justify-center w-20 py-1 text-sky-600 transition-all group">
        <span class="text-xl group-hover:scale-110 transition-transform">🪪</span>
        <span class="text-[10px] font-extrabold mt-0.5">KTA</span>
      </button>

      <button onclick="logout()" class="flex flex-col items-center justify-center w-20 py-1 text-slate-400 hover:text-rose-600 transition-all group">
        <span class="text-xl group-hover:scale-110 transition-transform">🚪</span>
        <span class="text-[10px] font-extrabold mt-0.5 text-slate-500 group-hover:text-rose-600">Exit</span>
      </button>
    `;
  } else {
    bottomNav.classList.add("hidden");
    bottomNav.classList.remove("flex");
  }
}

function navigateTo(pageName) {
  if (window.location.hash === "#" + pageName) {
    loadPage(pageName);
  } else {
    window.location.hash = pageName;
  }
}

async function loadPage(pageName) {
  const container = document.getElementById("app-content");
  if (!container) return;

  if (pageName === "login" && !currentUser && !userRole) {
    updateNavVisibility();
  } else if (
    (pageName === "user" || pageName === "edit") &&
    userRole !== "user"
  ) {
    window.location.hash = "login";
    return;
  } else if (pageName === "admin" && userRole !== "admin") {
    window.location.hash = "login";
    return;
  }

  updateNavVisibility();

  container.innerHTML = `
    <div class="flex flex-col items-center justify-center py-24 space-y-3">
      <div class="w-9 h-9 border-4 border-sky-600 border-t-transparent rounded-full animate-spin"></div>
      <p class="text-xs font-bold text-slate-400">Memuat halaman...</p>
    </div>`;

  try {
    const response = await fetch(`pages/${pageName}.html`);
    if (response.ok) {
      const html = await response.text();
      container.innerHTML = html;

      if (pageName === "user") initUserPage();
      if (pageName === "admin") initAdminPage();
      if (pageName === "edit") initEditPage();
    } else {
      container.innerHTML = `<div class="p-6 text-center text-xs font-bold text-rose-500">Halaman tidak ditemukan.</div>`;
    }
  } catch (err) {
    container.innerHTML = `<div class="p-6 text-center text-xs font-bold text-rose-500">Gagal memuat halaman: ${err.message}</div>`;
  }
}

// Event Listeners
window.addEventListener("hashchange", () => {
  const page = window.location.hash.replace("#", "") || "login";
  loadPage(page);
});

window.addEventListener("DOMContentLoaded", () => {
  loadSession();
  const initialPage = window.location.hash.replace("#", "") || "login";
  loadPage(initialPage);
});
