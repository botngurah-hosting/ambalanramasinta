const SCRIPT_URL =
  "https://script.google.com/macros/s/AKfycbz9Uf8oUccYuOU12fgo9HDE1NIAoQyt2sa9EMSwG4IYZsNf7KyjbFF_dFOhzfzUfSLAhw/exec";

let currentUser = null;
let userRole = "";
let globalAdminData = [];

// Helper Fetch Data JSON
async function safeFetch(url, options = {}) {
  const response = await fetch(url, options);
  const text = await response.text();
  try {
    return JSON.parse(text);
  } catch (e) {
    throw new Error("Respon server tidak valid.");
  }
}

// Format Gambar Google Drive
function formatDriveUrl(url) {
  if (!url || url === "-" || String(url).startsWith("ERROR")) return "";
  if (String(url).startsWith("data:image")) return url;
  const match = String(url).match(/[-\w]{25,}/);
  return match
    ? `https://drive.google.com/thumbnail?id=${match[0]}&sz=w1000`
    : url;
}

// Konversi File ke Base64
const fileToBase64 = (file) =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });

// Modal Loading Status
function showLoading(show, text = "Memproses data...") {
  const modal = document.getElementById("loadingModal");
  const label = document.getElementById("loadingText");
  if (!modal) return;
  if (show) {
    if (label) label.innerText = text;
    modal.classList.remove("hidden");
  } else {
    modal.classList.add("hidden");
  }
}
