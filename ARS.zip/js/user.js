function initUserPage() {
  if (!currentUser) return;

  const fotoEl = document.getElementById("u_foto");
  const idEl = document.getElementById("u_id");
  const namaEl = document.getElementById("u_nama");
  const angkatanEl = document.getElementById("u_angkatan");
  const ukuranEl = document.getElementById("u_ukuran");
  const bayarEl = document.getElementById("u_pembayaran");
  const hpEl = document.getElementById("u_hp");

  if (fotoEl)
    fotoEl.src =
      formatDriveUrl(currentUser.link_foto) ||
      "https://via.placeholder.com/150";
  if (idEl) idEl.innerText = currentUser.id || "-";
  if (namaEl) namaEl.innerText = currentUser.nama || "-";
  if (angkatanEl) angkatanEl.innerText = currentUser.angkatan || "-";
  if (ukuranEl) ukuranEl.innerText = currentUser.ukuran || "-";
  if (bayarEl) bayarEl.innerText = currentUser.pembayaran || "-";
  if (hpEl) hpEl.innerText = currentUser.no_hp || "-";
}

function initEditPage() {
  if (!currentUser) return;

  const namaEl = document.getElementById("edit_nama");
  const hpEl = document.getElementById("edit_hp");
  const ukuranEl = document.getElementById("edit_ukuran");

  if (namaEl) namaEl.value = currentUser.nama || "";
  if (hpEl) hpEl.value = currentUser.no_hp || "";
  if (ukuranEl) ukuranEl.value = currentUser.ukuran || "L";
}

async function handleRegisterSubmit(e) {
  e.preventDefault();
  showLoading(true, "Mendaftarkan anggota...");

  try {
    const nama = document.getElementById("reg_nama").value.trim();
    const angkatan = document.getElementById("reg_angkatan").value.trim();
    const ukuran = document.getElementById("reg_ukuran").value;
    const hp = document.getElementById("reg_hp").value.trim();
    const pembayaran = document.getElementById("reg_pembayaran").value;
    const keterangan = document.getElementById("reg_keterangan").value.trim();
    const fotoInput = document.getElementById("reg_foto");

    let fotoBase64 = "";
    if (fotoInput && fotoInput.files && fotoInput.files[0]) {
      fotoBase64 = await fileToBase64(fotoInput.files[0]);
    }

    const payload = {
      action: "register",
      nama,
      angkatan,
      ukuran,
      no_hp: hp,
      pembayaran,
      keterangan,
      foto: fotoBase64,
    };

    const response = await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
    });

    const res = await response.json();
    showLoading(false);

    if (res && res.status === "success") {
      alert("Pendaftaran berhasil! ID Anda: " + res.data.id);
      saveSession(res.data, "user");
      navigateTo("user");
    } else {
      alert("Gagal mendaftar: " + (res.message || "Terjadi kesalahan."));
    }
  } catch (err) {
    showLoading(false);
    alert("Gagal mengirim data: " + err.message);
  }
}

async function handleEditProfileSubmit(e) {
  e.preventDefault();
  if (!currentUser) return;

  showLoading(true, "Menyimpan perubahan...");

  try {
    const nama = document.getElementById("edit_nama").value.trim();
    const hp = document.getElementById("edit_hp").value.trim();
    const ukuran = document.getElementById("edit_ukuran").value;
    const pass = document.getElementById("edit_pass").value.trim();

    const payload = {
      action: "updateProfile",
      id: currentUser.id,
      nama,
      no_hp: hp,
      ukuran,
      password: pass,
    };

    const response = await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
    });

    const res = await response.json();
    showLoading(false);

    if (res && res.status === "success") {
      currentUser = { ...currentUser, ...res.data };
      saveSession(currentUser, userRole);
      alert("Profil berhasil diperbarui!");
      navigateTo("user");
    } else {
      alert("Gagal memperbarui: " + (res.message || "Terjadi kesalahan."));
    }
  } catch (err) {
    showLoading(false);
    alert("Gagal menyimpan data: " + err.message);
  }
}
