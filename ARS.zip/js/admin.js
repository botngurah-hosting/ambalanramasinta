function initAdminPage() {
  fetchAdminData();
}

async function fetchAdminData() {
  showLoading(true, "Memuat data anggota...");
  try {
    const res = await safeFetch(`${SCRIPT_URL}?action=getAdminData`);
    showLoading(false);

    if (res && res.status === "success") {
      globalAdminData = res.data || [];
      renderAdminTable(globalAdminData);
      updateAdminStats(globalAdminData);
    } else {
      alert("Gagal memuat data: " + (res.message || "Respons tidak valid"));
    }
  } catch (err) {
    showLoading(false);
    alert("Gagal mengambil data admin: " + err.message);
  }
}

function updateAdminStats(data) {
  const totalEl = document.getElementById("stat_total");
  const cashEl = document.getElementById("stat_cash");
  const transferEl = document.getElementById("stat_transfer");

  if (!totalEl) return;

  const total = data.length;
  const cash = data.filter(
    (d) => String(d.pembayaran).toLowerCase() === "cash",
  ).length;
  const transfer = data.filter(
    (d) => String(d.pembayaran).toLowerCase() === "transfer",
  ).length;

  totalEl.innerText = total;
  cashEl.innerText = cash;
  transferEl.innerText = transfer;
}

function renderAdminTable(data) {
  const tbody = document.getElementById("admin_table_body");
  if (!tbody) return;

  if (!data || data.length === 0) {
    tbody.innerHTML = `<tr><td colspan="4" class="p-4 text-center text-slate-400 font-medium">Tidak ada data anggota.</td></tr>`;
    return;
  }

  tbody.innerHTML = data
    .map(
      (item) => `
    <tr class="border-b border-slate-100 hover:bg-slate-50 transition-colors">
      <td class="p-2.5">
        <div class="font-extrabold text-slate-800 uppercase">${item.nama || "-"}</div>
        <div class="text-[9px] font-mono text-slate-400">${item.id || "-"}</div>
      </td>
      <td class="p-2.5 font-semibold text-slate-600">${item.angkatan || "-"}</td>
      <td class="p-2.5">
        <span class="px-2 py-0.5 rounded-md text-[9px] font-extrabold ${
          String(item.pembayaran).toLowerCase() === "cash"
            ? "bg-emerald-100 text-emerald-700"
            : "bg-sky-100 text-sky-700"
        }">
          ${item.pembayaran || "-"}
        </span>
      </td>
      <td class="p-2.5 text-center">
        <button onclick="deleteMember('${item.id}')" class="p-1 bg-rose-50 text-rose-600 rounded-lg text-xs hover:bg-rose-100" title="Hapus">
          🗑️
        </button>
      </td>
    </tr>
  `,
    )
    .join("");
}

function filterAdminTable() {
  const searchInput = document.getElementById("admin_search");
  if (!searchInput) return;

  const query = searchInput.value.toLowerCase();
  const filtered = globalAdminData.filter((item) => {
    return (
      (item.nama && item.nama.toLowerCase().includes(query)) ||
      (item.id && String(item.id).toLowerCase().includes(query)) ||
      (item.angkatan && String(item.angkatan).toLowerCase().includes(query))
    );
  });

  renderAdminTable(filtered);
}

async function deleteMember(id) {
  if (!confirm(`Apakah Anda yakin ingin menghapus anggota ID ${id}?`)) return;

  showLoading(true, "Menghapus data...");
  try {
    const payload = { action: "deleteUser", id: id };
    const response = await fetch(SCRIPT_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain;charset=utf-8" },
      body: JSON.stringify(payload),
    });
    const res = await response.json();

    showLoading(false);
    if (res && res.status === "success") {
      alert("Anggota berhasil dihapus.");
      fetchAdminData();
    } else {
      alert("Gagal menghapus: " + (res.message || "Terjadi kesalahan"));
    }
  } catch (err) {
    showLoading(false);
    alert("Gagal menghapus data: " + err.message);
  }
}
