// Kelola Sesi Penyimpanan Lokal
function saveSession(user, role) {
  currentUser = user;
  userRole = role;
  if (user) {
    sessionStorage.setItem("ars_user", JSON.stringify(user));
  } else {
    sessionStorage.removeItem("ars_user");
  }
  sessionStorage.setItem("ars_role", role || "");
}

function loadSession() {
  const savedUser = sessionStorage.getItem("ars_user");
  const savedRole = sessionStorage.getItem("ars_role");
  if (savedRole) {
    userRole = savedRole;
    currentUser = savedUser ? JSON.parse(savedUser) : null;
  }
}

function toggleLoginModal(show) {
  const modal = document.getElementById("loginBottomSheet");
  if (modal) {
    if (show) modal.classList.remove("hidden");
    else modal.classList.add("hidden");
  }
}

function closeLoginModal(e) {
  if (e.target.id === "loginBottomSheet") {
    toggleLoginModal(false);
  }
}

async function handleLogin(e) {
  e.preventDefault();
  const userVal = document.getElementById("login_user").value.trim();
  const passVal = document.getElementById("login_pass").value.trim();

  if (!userVal) return alert("Masukkan ID / Username!");

  showLoading(true, "Memeriksa kredensial...");
  try {
    if (userVal.toLowerCase() === "admin" && passVal === "admin123") {
      saveSession({ nama: "Administrator", id: "ADMIN" }, "admin");
      toggleLoginModal(false);
      showLoading(false);
      navigateTo("admin");
      return;
    }

    const res = await safeFetch(
      `${SCRIPT_URL}?action=login&username=${encodeURIComponent(userVal)}&password=${encodeURIComponent(passVal)}`,
    );

    showLoading(false);
    if (res && res.status === "success") {
      saveSession(res.data, res.role || "user");
      toggleLoginModal(false);
      if (res.role === "admin") {
        navigateTo("admin");
      } else {
        navigateTo("user");
      }
    } else {
      alert(res.message || "ID atau Kata Sandi salah!");
    }
  } catch (err) {
    showLoading(false);
    alert("Gagal terhubung ke server: " + err.message);
  }
}

function logout() {
  if (confirm("Apakah Anda yakin ingin keluar?")) {
    saveSession(null, "");
    updateNavVisibility();
    navigateTo("login");
  }
}
